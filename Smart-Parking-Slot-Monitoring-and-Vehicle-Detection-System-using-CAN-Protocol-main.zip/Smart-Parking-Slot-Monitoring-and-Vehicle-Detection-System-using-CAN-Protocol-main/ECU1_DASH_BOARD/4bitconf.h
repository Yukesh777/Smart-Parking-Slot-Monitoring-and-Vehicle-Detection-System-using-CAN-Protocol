//#include"delay.h"
 #define LCD_D 0XF<<23
#define RS 1<<27
#define E  1<<28

void LCD_init(void);
void LCD_data(unsigned char);
void LCD_str(unsigned char*);
void LCD_int(int);
void LCD_float(float);
void LCD_command(unsigned char);
void LCD_init(void)
{
IODIR1 |=LCD_D|RS|E;
//PINSEL0 |=0;
LCD_command(0x01);//clear the display
LCD_command(0x02);//return the cursor to home position
LCD_command(0x0C);//display on ,cursor off 
LCD_command(0x28);//8-bit interface made with both lines
}
/////////
void LCD_command(unsigned char command)
{
IOCLR1=LCD_D;//clear the data pins
IOSET1=(command&0xf0)<<19;//assign the command byte to data pins of lcd
IOCLR1=RS;// clear rws to selec command register
IOSET1=E;//latch the data to the lcd
delay_ms(2);
IOCLR1=E;//re latch the next byte

IOCLR1=LCD_D;//clear the data pins
IOSET1=(command&0x0f)<<23;//assign the command byte to data pins of lcd
IOCLR1=RS;// clear rws to selec command register
IOSET1=E;//latch the data to the lcd
delay_ms(2);
IOCLR1=E;//re latch the next byte
}
//////
void LCD_data(unsigned char data)
{
IOCLR1=LCD_D;//clear the data pins
IOSET1=(data&0xf0)<<19;//assign the data to data pins of lcd
IOSET1=RS;//set RS to select the data register
IOSET1=E;// latch the data
delay_ms(2);
IOCLR1=E;//re latch the next byte

IOCLR1=LCD_D;//clear the data pins
IOSET1=(data&0x0f)<<23;//assign the data to data pins of lcd
IOSET1=RS;//set RS to select the data register
IOSET1=E;// latch the data
delay_ms(2);
IOCLR1=E;//re latch the next byte
}
 void LCD_int(int number)

{
 unsigned char arr[100];
 signed char i=0;
 if(number==0)
 LCD_data('0');
 else
{
if(number<0)
{
LCD_data('-');
number=-number;
}
 while(number>0)
{
 arr[i++]=number%10;
 number=number/10;
}						
for(--i;i>=0;i--)
LCD_data(arr[i]+48);
}
}

void LCD_str(unsigned char *str)
{
while(*str)
{
LCD_data(*str++);
}
}


