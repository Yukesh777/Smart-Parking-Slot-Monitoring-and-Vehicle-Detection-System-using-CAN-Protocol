#include<LPC21xx.H>
#include"header.h"
void CAN2_init(void)
	{
		 PINSEL1|=0X00014000;//po.23,p0.24
		 VPBDIV=1;// speed 60mhz
		 C2MOD=0X1;	// can2 rest mode
		 AFMR=0X2;
		 C2BTR=0X001C001D;
		 C2MOD=0X0;
	}
void CAN2_tx(CAN2_MSG m1)
   {
   		C2TID1=m1.id;
		C2TFI1=(m1.dlc<<16);
		if(m1.rtr==0)//data frame
		{
		C2TFI1&=~(1<<30);
		C2TDA1=m1.ByteA;
		C2TDB1=m1.ByteB;
		}
		else
		{
		C2TFI1|=(1<<30);
		}
		C2CMR=(1<<0)|(1<<5);
		while((C2GSR&(1<<3))==0);
    } 


void CAN2_rx(CAN2_MSG *m1)
{
	while((C2GSR & 0x1)==0);
	m1->id=C2RID;
	m1->dlc=(C2RFS>>16)&0xf;
	m1->rtr=(C2RFS>>30)&0x1;
	if(m1->rtr==0)
	{
	m1->ByteA=C2RDA;
	m1->ByteB=C2RDB;
	}
	C2CMR=(1<<2);
} 

