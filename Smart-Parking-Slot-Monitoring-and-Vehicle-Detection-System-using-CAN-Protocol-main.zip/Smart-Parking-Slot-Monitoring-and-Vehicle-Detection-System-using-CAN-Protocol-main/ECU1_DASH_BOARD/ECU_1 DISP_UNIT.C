#include<lpc21xx.h>
#include"delay.h"
#include"4bitconf.h"
#include"CAN_driver.c"
int main()
{
unsigned char hr,min,sec,slot=6;
CAN2_MSG m1;
LCD_init();
CAN2_init();
LCD_command(0x80);
LCD_str("TOTAL SLOT:6");

while(1)
{
CAN2_rx(&m1);
LCD_command(0xc0);
LCD_str("AVAILABLE SLOT:");
if(m1.id==0x101)
	{
	slot=m1.ByteA;
	LCD_command(0xcf);
	LCD_int(m1.ByteA);
	}
if(m1.id==0x103)
	{
	slot=m1.ByteA;
	LCD_command(0xcf);
	LCD_int(m1.ByteA);
	}
if(m1.id==0x102)
{
    hr  = (m1.ByteA) & 0xFF;
    min = (m1.ByteA >> 8) & 0xFF;
    sec = (m1.ByteA >> 16) & 0xFF;
    LCD_command(0x94);
    LCD_data((hr/16)+'0');
    LCD_data((hr%16)+'0');
    LCD_data(':');
    LCD_data((min/16)+'0');
    LCD_data((min%16)+'0');
    LCD_data(':');
    LCD_data((sec/16)+'0');
    LCD_data((sec%16)+'0');
	LCD_command(0xd4);
	LCD_str(" CAR ENTRY ");
	delay_ms(3000);
	LCD_command(0xd4);
	LCD_str("              ");
	LCD_command(0xd4);
	LCD_str("GATE OPEN     ");
	delay_ms(3000);
	LCD_command(0xd4);
	LCD_str("GATE CLOSED  ");
	delay_ms(2000);
	
}

if(m1.id==0x104)
{
    hr  = (m1.ByteA) & 0xFF;
    min = (m1.ByteA >> 8) & 0xFF;
    sec = (m1.ByteA >> 16) & 0xFF;
    LCD_command(0x94);
    LCD_data((hr/16)+'0');
    LCD_data((hr%16)+'0');
    LCD_data(':');
    LCD_data((min/16)+'0');
    LCD_data((min%16)+'0');
    LCD_data(':');
    LCD_data((sec/16)+'0');
    LCD_data((sec%16)+'0');
	LCD_command(0xd4);
	LCD_str(" CAR EXIT ");
	delay_ms(3000);
	LCD_command(0xd4);

	LCD_command(0xd4);
	LCD_str("GATE OPEN     ");
	delay_ms(5000);
	LCD_command(0xd4);
	LCD_str("GATE CLOSED  ");
	delay_ms(3000);
	LCD_command(0xd4);
	LCD_str("              ");
	
}
// Parking full 
if(slot==0)
	{
	//LCD_command(0x01);
	LCD_command(0xd4);
//	LCD_str("              ");
	LCD_str(" PARKING FULL ");
	delay_ms(1000);
	}

}	
 }