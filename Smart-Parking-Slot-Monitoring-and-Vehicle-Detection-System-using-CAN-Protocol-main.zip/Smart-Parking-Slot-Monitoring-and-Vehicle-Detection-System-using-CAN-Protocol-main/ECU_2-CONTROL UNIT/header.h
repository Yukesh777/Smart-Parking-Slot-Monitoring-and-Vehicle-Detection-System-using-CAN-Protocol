#ifndef _HEADER_H_
#define _HEADER_H_

#define led 1<<17;

typedef unsigned int u32;
typedef signed int s32;
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short int u16;
typedef signed short int s16;

typedef struct CAN2
{
u32 id;
u32 rtr;
u32 dlc;
u32 ByteA;
u8 ByteB;
}CAN2_MSG;

void CAN2_init(void);
void CAN2_tx(CAN2_MSG);
void uart0_init(unsigned int);
void uart0_tx(unsigned char);
unsigned char uart0_rx(void);
void uart0_tx_string(char *);
void uart0_tx_integer(int);
void uart0_tx_hex(int);

#endif


							