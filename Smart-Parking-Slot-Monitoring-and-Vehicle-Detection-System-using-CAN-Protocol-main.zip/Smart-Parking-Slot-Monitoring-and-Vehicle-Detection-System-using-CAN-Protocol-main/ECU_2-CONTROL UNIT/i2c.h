#ifndef __I2C_H__
#define __I2C_H__

void init_i2c(void);
void i2c_start(void);
void i2c_stop(void);
void i2c_restart(void);
u8 i2c_nack(void);
void i2c_write(u8);
u8 i2c_masterack(void);

#endif


