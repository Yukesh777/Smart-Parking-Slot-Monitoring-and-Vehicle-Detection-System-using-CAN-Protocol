#include<lpc21xx.h>
#include "delay.h"
#include "4bitconf.h"
#include"CAN_driver.c"
#define SW1 1<<10
#define SW2 1<<11
void current_time(void);
unsigned char hr,min,sec;
int main()
{
CAN2_MSG m1,m2;
//CAN2_MSG2 m2;
int slot =6;
//LCD_init();
init_i2c();
CAN2_init();

i2c_eeprom_write(0x68,0x02,0x08);//hr
i2c_eeprom_write(0x68,0x01,0x10);//min
i2c_eeprom_write(0x68,0x00,0x00);//sec 
//LCD_command(0x80);
//LCD_str("TOTAL SLOT:6");
while(1)
{     
if((IOPIN0 & SW1)==0)
{
delay_ms(1000);
while((IOPIN0 & SW1) == 0);
if(slot > 0)
{
slot--;
 //msg	1 to ecu 1
m1.id=0x101;
m1.rtr=0;
m1.dlc=	4;
m1.ByteA=slot;
m1.ByteB=0;
CAN2_tx(m1);
   //msg 2 to ecu1
hr=i2c_eeprom_read(0X68,0X02);
min=i2c_eeprom_read(0X68,0X01);
sec=i2c_eeprom_read(0X68,0X00);

m1.id=0x102;
m1.rtr=0;
m1.dlc=	4;
m1.ByteA=((u32)hr) |((u32)min<<8) |((u32)sec<<16);
m1.ByteB=0;
CAN2_tx(m1);
delay_ms(1000);
}
}
///exit
// EXIT

if((IOPIN0 & SW2)==0)
{
    delay_ms(500);

    while((IOPIN0 & SW2)==0);


    if(slot<6)
    {
        slot++;


        m2.id=0x103;
        m2.rtr=0;
        m2.dlc=4;

        m2.ByteA=slot;
        m2.ByteB=0;

        CAN2_tx(m2);



        hr=i2c_eeprom_read(0x68,0x02);
        min=i2c_eeprom_read(0x68,0x01);
        sec=i2c_eeprom_read(0x68,0x00);



        m2.id=0x104;
        m2.rtr=0;
        m2.dlc=4;

        m2.ByteA=((u32)hr) |
                 ((u32)min<<8) |
                 ((u32)sec<<16);

        m2.ByteB=0;

        CAN2_tx(m2);
    }
}
}
} 	




