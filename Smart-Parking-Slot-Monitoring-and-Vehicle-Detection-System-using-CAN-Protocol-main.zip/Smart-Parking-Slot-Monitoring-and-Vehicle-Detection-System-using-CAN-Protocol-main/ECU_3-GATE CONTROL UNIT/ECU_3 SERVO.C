#include<LPC21xx.h>        
#include"delay.h"           
#include"CAN_driver.c"      
CAN2_MSG m1;                
void PWM_Init(void)
{
PINSEL0|=0x00008000;         // Configure P0.7 as PWM2 output
PWMTCR=0x02;                 // Reset PWM counter
PWMPR=59;                    // Prescaler value (60MHz/(59+1)=1MHz)
PWMMR0=20000;                // PWM period 20ms (50Hz servo frequency)
PWMMR2=1000;                 // 1ms pulse, servo gate closed position
PWMPCR=(1<<10);              // Enable PWM2 output
PWMLER=(1<<0)|(1<<2);        // Load PWM match values
PWMTCR=0x09;                 // Enable PWM and start counter
}
void Gate_Open(void)
{
PWMMR2=2000;                 // 2ms pulse, servo gate open position
PWMLER=(1<<2);               // Update PWM2 match register
delay_ms(3000);              // Keep gate open for 3 seconds
}
void Gate_Close(void)
{
PWMMR2=1000;                 // 1ms pulse, servo gate close position
PWMLER=(1<<2);               // Update PWM2 match register
delay_ms(2000);              // Delay for gate closing
}
int main()
{
CAN2_init();                 // Initialize CAN2 communication
PWM_Init();                  // Initialize PWM for servo motor
Gate_Close();                // Initially gate is closed
while(1)
{
CAN2_rx(&m1);                // Receive CAN message
if(m1.id==0x102)             // CAN ID 0x102 indicates car entry
{
Gate_Open();                // Open gate
Gate_Close();               // Close gate
}
if(m1.id==0x104)             // CAN ID 0x104 indicates car exit
{
Gate_Open();                // Open gate
delay_ms(5000);             // Wait for vehicle exit
Gate_Close();               // Close gate
}
}
}