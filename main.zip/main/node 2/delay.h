void delay_ms(unsigned int ms)
{
	T0PR=15000-1;
	T0TCR=0x01;
  while(T0TC<ms);
  T0TCR=0x03;
  T0TCR=0x00;	
}
void delay_s(unsigned int s)
{
	T0PR=15000000-1;
	T0TCR=0x01;
  while(T0TC<s);
  T0TCR=0x03;
  T0TCR=0x00;	
}
void delay_canms(unsigned int canms){
	T0PR=60000-1;
	T0TC=T0PC=0;
	T0TCR=0x1;
	while(T0TC<canms);
	T0TCR=0x0;
}
