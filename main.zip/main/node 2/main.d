main.o: main.c
main.o: C:\Keil\ARM\Inc\Philips\LPC21xx.h
main.o: delay.h
main.o: can.h
main.o: uart.h
main.o: C:\Keil\ARM\ARMCC\bin\..\include\stdio.h
