void i2c_eeprom_write(unsigned char slaveAddr,unsigned char wDummy,unsigned char dat)
{
  i2c_start();	
  i2c_write(slaveAddr<<1);
	i2c_write(wDummy);
	i2c_write(dat);
	i2c_stop();
	delay_ms(10);
}			 

unsigned char i2c_eeprom_read(unsigned char slaveAddr,unsigned char rDummyAddr)
{
	unsigned char dat;
	i2c_start();	
  i2c_write(slaveAddr<<1);
	i2c_write(rDummyAddr);
	i2c_restart();	
	i2c_write(slaveAddr<<1|1); 
  dat=i2c_nack();	
	i2c_stop();
	return dat;
}

void i2c_eeprom_page_write(unsigned char slaveAddr,unsigned char wDummyStartAddr,unsigned char *p,unsigned char nBytes)
{
  unsigned char i;
  i2c_start();	
  i2c_write(slaveAddr<<1);
	i2c_write(wDummyStartAddr);
	for(i=0;i<nBytes;i++)
	{
	   i2c_write(p[i]);       
	}
	i2c_stop();
	delay_ms(10);
}			 

void i2c_eeprom_seq_read(unsigned char slaveAddr,unsigned char rDummyStartAddr,unsigned char *p,unsigned char nBytes)
{
	unsigned char i;
	i2c_start();	
  i2c_write(slaveAddr<<1);
	i2c_write(rDummyStartAddr);
	i2c_restart();	
	i2c_write(slaveAddr<<1|1);
	for(i=0;i<nBytes-1;i++)
	{
    p[i]=i2c_masterack();	
	}
	p[i]=i2c_nack();
	i2c_stop();
}

