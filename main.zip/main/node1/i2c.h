void init_i2c(void)
{
	  PINSEL0 |= 0X00000050;
	  I2SCLL=(((6000000/4)/100000)/2);
	  I2SCLH=(((6000000/4)/100000)/2);
	  I2CONSET=1<<(0x00000010); 
}	

void i2c_start(void)
{
  I2CONSET=1<<5;
	while(((I2CONSET>>3)&1)==0);
	I2CONCLR=1<<5;
}	

void i2c_restart(void)
{
	I2CONSET=1<<5;
	I2CONCLR=1<<3;
	while(((I2CONSET>>3)&1)==0);
	I2CONCLR=1<<5;
}	

void i2c_write(unsigned char dat)
{
	I2DAT=dat;	
	I2CONCLR = 1<<3;
	while(((I2CONSET>>3)&1)==0);
}	

void i2c_stop(void)
{
	I2CONSET=1<<4;	
	I2CONCLR = 1<<3;
	}

unsigned char i2c_nack(void)
{	
  I2CONCLR = 1<<3;
	while(((I2CONSET>>3)&1)==0);
	return I2DAT;
}

unsigned char i2c_masterack(void)
{	
	I2CONSET = 0x04;
  I2CONCLR = 1<<3;
	while(((I2CONSET>>3)&1)==0);
	I2CONCLR = 0x04;
 	return I2DAT;
}	

